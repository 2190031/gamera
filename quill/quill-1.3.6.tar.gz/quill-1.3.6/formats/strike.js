import Inline from '../blots/inline';

class Strike extends Inline { }
Strike.blotName = 'strike';
Strike.tagName = 'S';

export default Strike;
